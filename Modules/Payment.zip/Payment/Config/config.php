<?php

return [
    'name' => 'Payment'
];
